print(bytes((2,)))
input()