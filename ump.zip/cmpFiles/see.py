
name = input("File Name: ")
with open(name, "rb") as f:
    x = f.read()
print(x)
input()
